# BCARD

What is CARDbuyers ?

CARDbuyers  is a new way to use crypto to buy your favorite games and your favorite stuff safely using Amazon gift card, steam card, Apple card, PaySafe card or even Google play card.
We are a new decentralized and anonymous crypto currency. It is open source and accessible to all. Our coin will have a PoW phase so you can all have a chance to grab some coins then we will switch to PoS.
